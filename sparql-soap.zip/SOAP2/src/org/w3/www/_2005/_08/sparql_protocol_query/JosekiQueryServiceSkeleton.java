/**
 * JosekiQueryServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.w3.www._2005._08.sparql_protocol_query;

/**
 *  JosekiQueryServiceSkeleton java skeleton for the axisService
 */
public class JosekiQueryServiceSkeleton {
    /**
     * Auto generated method signature
     * @param queryRequest
     */
    public org.w3.www._2005._09.sparql_protocol_types.QueryResult query(
        org.w3.www._2005._09.sparql_protocol_types.QueryRequest queryRequest)
        throws MalformedQuery, QueryRequestRefused {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#query");
    }
}
