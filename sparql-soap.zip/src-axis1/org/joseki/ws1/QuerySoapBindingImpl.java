/**
 * QuerySoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jun 14, 2005 (09:15:57 EDT) WSDL2Java emitter.
 */

package org.joseki.ws1;
import org.joseki.soap.SPARQL_P;
import org.w3.www._2005._09.sparql_protocol_types.* ;

public class QuerySoapBindingImpl extends SPARQL_P implements SparqlQuery
{
    public QueryResult query(QueryRequest request)
    throws java.rmi.RemoteException, MalformedQuery, QueryRequestRefused 
    {
        return super.query(request) ;
    }

}
